/*
 * @lc app=leetcode.cn id=1585 lang=cpp
 *
 * [1585] 检查字符串是否可以通过排序子字符串得到另一个字符串
 */

// @lc code=start
class Solution {
public:
    bool isTransformable(string s, string t) {

    }
};
// @lc code=end

