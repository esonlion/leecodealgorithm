/*
 * @lc app=leetcode.cn id=1096 lang=cpp
 *
 * [1096] 花括号展开 II
 */

// @lc code=start
class Solution {
public:
    vector<string> braceExpansionII(string expression) {

    }
};
// @lc code=end

