/*
 * @lc app=leetcode.cn id=1610 lang=cpp
 *
 * [1610] 可见点的最大数目
 */

// @lc code=start
class Solution {
public:
    int visiblePoints(vector<vector<int>>& points, int angle, vector<int>& location) {

    }
};
// @lc code=end

