/*
 * @lc app=leetcode.cn id=1703 lang=cpp
 *
 * [1703] 得到连续 K 个 1 的最少相邻交换次数
 */

// @lc code=start
class Solution {
public:
    int minMoves(vector<int>& nums, int k) {

    }
};
// @lc code=end

