/*
 * @lc app=leetcode.cn id=1439 lang=cpp
 *
 * [1439] 有序矩阵中的第 k 个最小数组和
 */

// @lc code=start
class Solution {
public:
    int kthSmallest(vector<vector<int>>& mat, int k) {

    }
};
// @lc code=end

