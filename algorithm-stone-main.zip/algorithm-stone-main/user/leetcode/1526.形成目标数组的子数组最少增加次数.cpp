/*
 * @lc app=leetcode.cn id=1526 lang=cpp
 *
 * [1526] 形成目标数组的子数组最少增加次数
 */

// @lc code=start
class Solution {
public:
    int minNumberOperations(vector<int>& target) {

    }
};
// @lc code=end

