/*
 * @lc app=leetcode.cn id=770 lang=cpp
 *
 * [770] 基本计算器 IV
 */

// @lc code=start
class Solution {
public:
    vector<string> basicCalculatorIV(string expression, vector<string>& evalvars, vector<int>& evalints) {

    }
};
// @lc code=end

