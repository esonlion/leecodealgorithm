/*
 * @lc app=leetcode.cn id=591 lang=cpp
 *
 * [591] 标签验证器
 */

// @lc code=start
class Solution {
public:
    bool isValid(string code) {

    }
};
// @lc code=end

