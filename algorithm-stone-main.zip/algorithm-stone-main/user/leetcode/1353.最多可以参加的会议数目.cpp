/*
 * @lc app=leetcode.cn id=1353 lang=cpp
 *
 * [1353] 最多可以参加的会议数目
 */

// @lc code=start
class Solution {
public:
    int maxEvents(vector<vector<int>>& events) {

    }
};
// @lc code=end

