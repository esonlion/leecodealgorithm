/*
 * @lc app=leetcode.cn id=1521 lang=cpp
 *
 * [1521] 找到最接近目标值的函数值
 */

// @lc code=start
class Solution {
public:
    int closestToTarget(vector<int>& arr, int target) {

    }
};
// @lc code=end

