/*
 * @lc app=leetcode.cn id=778 lang=cpp
 *
 * [778] 水位上升的泳池中游泳
 */

// @lc code=start
class Solution {
public:
    int swimInWater(vector<vector<int>>& grid) {

    }
};
// @lc code=end

