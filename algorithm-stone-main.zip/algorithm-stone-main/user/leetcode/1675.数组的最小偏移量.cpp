/*
 * @lc app=leetcode.cn id=1675 lang=cpp
 *
 * [1675] 数组的最小偏移量
 */

// @lc code=start
class Solution {
public:
    int minimumDeviation(vector<int>& nums) {

    }
};
// @lc code=end

