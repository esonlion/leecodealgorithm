/*
 * @lc app=leetcode.cn id=1687 lang=cpp
 *
 * [1687] 从仓库到码头运输箱子
 */

// @lc code=start
class Solution {
public:
    int boxDelivering(vector<vector<int>>& boxes, int portsCount, int maxBoxes, int maxWeight) {

    }
};
// @lc code=end

