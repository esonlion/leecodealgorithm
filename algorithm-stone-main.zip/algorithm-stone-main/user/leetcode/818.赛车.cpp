/*
 * @lc app=leetcode.cn id=818 lang=cpp
 *
 * [818] 赛车
 */

// @lc code=start
class Solution {
public:
    int racecar(int target) {

    }
};
// @lc code=end

