/*
 * @lc app=leetcode.cn id=880 lang=cpp
 *
 * [880] 索引处的解码字符串
 */

// @lc code=start
class Solution {
public:
    string decodeAtIndex(string S, int K) {

    }
};
// @lc code=end

