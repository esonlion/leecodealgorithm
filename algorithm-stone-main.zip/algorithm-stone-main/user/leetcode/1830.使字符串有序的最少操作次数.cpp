/*
 * @lc app=leetcode.cn id=1830 lang=cpp
 *
 * [1830] 使字符串有序的最少操作次数
 */

// @lc code=start
class Solution {
public:
    int makeStringSorted(string s) {

    }
};
// @lc code=end

