/*
 * @lc app=leetcode.cn id=1453 lang=cpp
 *
 * [1453] 圆形靶内的最大飞镖数量
 */

// @lc code=start
class Solution {
public:
    int numPoints(vector<vector<int>>& points, int r) {

    }
};
// @lc code=end

