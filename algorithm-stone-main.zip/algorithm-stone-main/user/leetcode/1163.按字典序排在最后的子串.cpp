/*
 * @lc app=leetcode.cn id=1163 lang=cpp
 *
 * [1163] 按字典序排在最后的子串
 */

// @lc code=start
class Solution {
public:
    string lastSubstring(string s) {

    }
};
// @lc code=end

