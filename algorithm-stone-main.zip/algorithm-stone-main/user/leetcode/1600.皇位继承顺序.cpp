/*
 * @lc app=leetcode.cn id=1600 lang=cpp
 *
 * [1600] 皇位继承顺序
 */

// @lc code=start
class ThroneInheritance {
public:
    ThroneInheritance(string kingName) {

    }
    
    void birth(string parentName, string childName) {

    }
    
    void death(string name) {

    }
    
    vector<string> getInheritanceOrder() {

    }
};

/**
 * Your ThroneInheritance object will be instantiated and called as such:
 * ThroneInheritance* obj = new ThroneInheritance(kingName);
 * obj->birth(parentName,childName);
 * obj->death(name);
 * vector<string> param_3 = obj->getInheritanceOrder();
 */
// @lc code=end

