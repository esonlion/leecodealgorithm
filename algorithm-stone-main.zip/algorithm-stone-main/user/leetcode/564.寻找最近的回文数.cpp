/*
 * @lc app=leetcode.cn id=564 lang=cpp
 *
 * [564] 寻找最近的回文数
 */

// @lc code=start
class Solution {
public:
    string nearestPalindromic(string n) {

    }
};
// @lc code=end

