/*
 * @lc app=leetcode.cn id=1542 lang=cpp
 *
 * [1542] 找出最长的超赞子字符串
 */

// @lc code=start
class Solution {
public:
    int longestAwesome(string s) {

    }
};
// @lc code=end

