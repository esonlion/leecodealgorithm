/*
 * @lc app=leetcode.cn id=1948 lang=cpp
 *
 * [1948] 删除系统中的重复文件夹
 */

// @lc code=start
class Solution {
public:
    vector<vector<string>> deleteDuplicateFolder(vector<vector<string>>& paths) {

    }
};
// @lc code=end

