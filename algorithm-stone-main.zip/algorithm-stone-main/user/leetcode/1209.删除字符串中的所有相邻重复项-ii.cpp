/*
 * @lc app=leetcode.cn id=1209 lang=cpp
 *
 * [1209] 删除字符串中的所有相邻重复项 II
 */

// @lc code=start
class Solution {
public:
    string removeDuplicates(string s, int k) {

    }
};
// @lc code=end

