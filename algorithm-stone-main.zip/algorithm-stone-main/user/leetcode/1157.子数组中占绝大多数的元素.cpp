/*
 * @lc app=leetcode.cn id=1157 lang=cpp
 *
 * [1157] 子数组中占绝大多数的元素
 */

// @lc code=start
class MajorityChecker {
public:
    MajorityChecker(vector<int>& arr) {

    }
    
    int query(int left, int right, int threshold) {

    }
};

/**
 * Your MajorityChecker object will be instantiated and called as such:
 * MajorityChecker* obj = new MajorityChecker(arr);
 * int param_1 = obj->query(left,right,threshold);
 */
// @lc code=end

