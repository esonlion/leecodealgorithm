/*
 * @lc app=leetcode.cn id=1705 lang=cpp
 *
 * [1705] 吃苹果的最大数目
 */

// @lc code=start
class Solution {
public:
    int eatenApples(vector<int>& apples, vector<int>& days) {

    }
};
// @lc code=end

