/*
 * @lc app=leetcode.cn id=1106 lang=cpp
 *
 * [1106] 解析布尔表达式
 */

// @lc code=start
class Solution {
public:
    bool parseBoolExpr(string expression) {

    }
};
// @lc code=end

