/*
 * @lc app=leetcode.cn id=715 lang=cpp
 *
 * [715] Range 模块
 */

// @lc code=start
class RangeModule {
public:
    RangeModule() {

    }
    
    void addRange(int left, int right) {

    }
    
    bool queryRange(int left, int right) {

    }
    
    void removeRange(int left, int right) {

    }
};

/**
 * Your RangeModule object will be instantiated and called as such:
 * RangeModule* obj = new RangeModule();
 * obj->addRange(left,right);
 * bool param_2 = obj->queryRange(left,right);
 * obj->removeRange(left,right);
 */
// @lc code=end

