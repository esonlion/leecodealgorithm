/*
 * @lc app=leetcode.cn id=882 lang=cpp
 *
 * [882] 细分图中的可到达结点
 */

// @lc code=start
class Solution {
public:
    int reachableNodes(vector<vector<int>>& edges, int maxMoves, int n) {

    }
};
// @lc code=end

