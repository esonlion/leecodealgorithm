/*
 * @lc app=leetcode.cn id=936 lang=cpp
 *
 * [936] 戳印序列
 */

// @lc code=start
class Solution {
public:
    vector<int> movesToStamp(string stamp, string target) {

    }
};
// @lc code=end

