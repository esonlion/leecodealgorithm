/*
 * @lc app=leetcode.cn id=932 lang=cpp
 *
 * [932] 漂亮数组
 */

// @lc code=start
class Solution {
public:
    vector<int> beautifulArray(int n) {

    }
};
// @lc code=end

