/*
 * @lc app=leetcode.cn id=1719 lang=cpp
 *
 * [1719] 重构一棵树的方案数
 */

// @lc code=start
class Solution {
public:
    int checkWays(vector<vector<int>>& pairs) {

    }
};
// @lc code=end

