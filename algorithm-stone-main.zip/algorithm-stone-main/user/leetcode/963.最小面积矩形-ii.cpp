/*
 * @lc app=leetcode.cn id=963 lang=cpp
 *
 * [963] 最小面积矩形 II
 */

// @lc code=start
class Solution {
public:
    double minAreaFreeRect(vector<vector<int>>& points) {

    }
};
// @lc code=end

