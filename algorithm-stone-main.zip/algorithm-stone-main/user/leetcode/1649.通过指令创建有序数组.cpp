/*
 * @lc app=leetcode.cn id=1649 lang=cpp
 *
 * [1649] 通过指令创建有序数组
 */

// @lc code=start
class Solution {
public:
    int createSortedArray(vector<int>& instructions) {

    }
};
// @lc code=end

