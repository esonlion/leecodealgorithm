/*
 * @lc app=leetcode.cn id=1515 lang=cpp
 *
 * [1515] 服务中心的最佳位置
 */

// @lc code=start
class Solution {
public:
    double getMinDistSum(vector<vector<int>>& positions) {

    }
};
// @lc code=end

