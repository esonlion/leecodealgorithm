/*
 * @lc app=leetcode.cn id=1381 lang=cpp
 *
 * [1381] 设计一个支持增量操作的栈
 */

// @lc code=start
class CustomStack {
public:
    CustomStack(int maxSize) {
        
    }
    
    void push(int x) {
        
    }
    
    int pop() {
        
    }
    
    void increment(int k, int val) {
        
    }
};

/**
 * Your CustomStack object will be instantiated and called as such:
 * CustomStack* obj = new CustomStack(maxSize);
 * obj->push(x);
 * int param_2 = obj->pop();
 * obj->increment(k,val);
 */
// @lc code=end

