/*
 * @lc app=leetcode.cn id=1449 lang=cpp
 *
 * [1449] 数位成本和为目标值的最大数字
 */

// @lc code=start
class Solution {
public:
    string largestNumber(vector<int>& cost, int target) {

    }
};
// @lc code=end

