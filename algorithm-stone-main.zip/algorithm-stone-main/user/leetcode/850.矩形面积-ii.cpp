/*
 * @lc app=leetcode.cn id=850 lang=cpp
 *
 * [850] 矩形面积 II
 */

// @lc code=start
class Solution {
public:
    int rectangleArea(vector<vector<int>>& rectangles) {

    }
};
// @lc code=end

