/*
 * @lc app=leetcode.cn id=1466 lang=cpp
 *
 * [1466] 重新规划路线
 */

// @lc code=start
class Solution {
public:
    int minReorder(int n, vector<vector<int>>& connections) {

    }
};
// @lc code=end

