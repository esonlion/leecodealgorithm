/*
 * @lc app=leetcode.cn id=1316 lang=cpp
 *
 * [1316] 不同的循环子字符串
 */

// @lc code=start
class Solution {
public:
    int distinctEchoSubstrings(string text) {

    }
};
// @lc code=end

