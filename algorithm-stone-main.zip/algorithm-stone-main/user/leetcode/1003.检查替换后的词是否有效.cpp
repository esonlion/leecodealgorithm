/*
 * @lc app=leetcode.cn id=1003 lang=cpp
 *
 * [1003] 检查替换后的词是否有效
 */

// @lc code=start
class Solution {
public:
    bool isValid(string s) {

    }
};
// @lc code=end

