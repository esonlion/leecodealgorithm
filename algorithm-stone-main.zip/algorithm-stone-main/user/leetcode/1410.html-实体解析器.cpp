/*
 * @lc app=leetcode.cn id=1410 lang=cpp
 *
 * [1410] HTML 实体解析器
 */

// @lc code=start
class Solution {
public:
    string entityParser(string text) {

    }
};
// @lc code=end

