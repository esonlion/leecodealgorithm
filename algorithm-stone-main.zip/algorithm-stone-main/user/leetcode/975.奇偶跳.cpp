/*
 * @lc app=leetcode.cn id=975 lang=cpp
 *
 * [975] 奇偶跳
 */

// @lc code=start
class Solution {
public:
    int oddEvenJumps(vector<int>& arr) {

    }
};
// @lc code=end

