/*
 * @lc app=leetcode.cn id=1803 lang=cpp
 *
 * [1803] 统计异或值在范围内的数对有多少
 */

// @lc code=start
class Solution {
public:
    int countPairs(vector<int>& nums, int low, int high) {

    }
};
// @lc code=end

