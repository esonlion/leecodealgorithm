/*
 * @lc app=leetcode.cn id=864 lang=cpp
 *
 * [864] 获取所有钥匙的最短路径
 */

// @lc code=start
class Solution {
public:
    int shortestPathAllKeys(vector<string>& grid) {

    }
};
// @lc code=end

