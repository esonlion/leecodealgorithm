/*
 * @lc app=leetcode.cn id=456 lang=cpp
 *
 * [456] 132模式
 */

// @lc code=start
class Solution {
public:
    bool find132pattern(vector<int>& nums) {

    }
};
// @lc code=end

