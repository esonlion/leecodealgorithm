/*
 * @lc app=leetcode.cn id=899 lang=cpp
 *
 * [899] 有序队列
 */

// @lc code=start
class Solution {
public:
    string orderlyQueue(string s, int k) {

    }
};
// @lc code=end

