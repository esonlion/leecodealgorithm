/*
 * @lc app=leetcode.cn id=1392 lang=cpp
 *
 * [1392] 最长快乐前缀
 */

// @lc code=start
class Solution {
public:
    string longestPrefix(string s) {

    }
};
// @lc code=end

