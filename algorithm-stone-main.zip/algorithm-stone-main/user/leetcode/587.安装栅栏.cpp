/*
 * @lc app=leetcode.cn id=587 lang=cpp
 *
 * [587] 安装栅栏
 */

// @lc code=start
class Solution {
public:
    vector<vector<int>> outerTrees(vector<vector<int>>& points) {

    }
};
// @lc code=end

