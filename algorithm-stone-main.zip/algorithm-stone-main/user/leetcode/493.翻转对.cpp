/*
 * @lc app=leetcode.cn id=493 lang=cpp
 *
 * [493] 翻转对
 */

// @lc code=start
class Solution {
public:
    int reversePairs(vector<int>& nums) {

    }
};
// @lc code=end

