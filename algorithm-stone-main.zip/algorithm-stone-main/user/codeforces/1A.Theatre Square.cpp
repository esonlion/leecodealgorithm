#include<iostream>
using namespace std;

long long n,m,a;

int main()
{
	
	
	cin>>n>>m>>a;
	cout<<((n-1)/a+1)*((m-1)/a+1);
	
	
	return 0;
}
