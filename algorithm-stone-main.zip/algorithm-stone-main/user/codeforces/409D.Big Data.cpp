#include<bits/stdc++.h>
using namespace std;  

char s[]="1001010111001010";  

int main() 
{  
    int n;  
    cin>>n;
    cout<<s[n-1];
		 
    return 0;  
}  
