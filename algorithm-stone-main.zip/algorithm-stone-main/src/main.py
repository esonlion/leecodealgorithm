import leetcode_view
import codeforces_view

def main():
    leetcode_view.process()
    codeforces_view.process()

if __name__ == "__main__":
    main()
